# Student Management System
**Course:** DIWA2110 • Web Application Development  
**Institution:** Limkokwing University of Creative Technology  
**Assignment:** Individual Assignment — Interactive Student Management System (100 Marks)

---

## 🌟 Overview

The **Interactive Student Management System** is a responsive web application built with **React** and **JavaScript**. It allows administrators and faculty to view, search, filter, add, edit, and delete student records through an intuitive user interface without page reloads.

---

## 📋 Features Implemented

1. **Dashboard & Structured Display**:
   - Displays student records in a clean, modern, accessible data table.
   - Shows Student ID, Full Name, Age, Email Address, Course of Study, and Enrollment Status.
   - Badges indicate active, probation, or inactive status with color coding.

2. **Add Student (Modal)**:
   - Interactive pop-up dialog with controlled form inputs.
   - Comprehensive input validation with inline warning messages.
   - Converts numeric age to JavaScript `Number` primitive.
   - Prevents duplicate Student IDs.

3. **Edit Student (Modal)**:
   - Pre-populates the modal with the selected student's existing details.
   - Protects Student ID from modification to maintain record integrity.
   - Updates state immediately across the table.

4. **Delete Student (Confirmation Modal)**:
   - Safeguards against accidental deletion by prompting with a confirmation modal.
   - Shows the student's ID, Name, and Course before deletion.

5. **Search & Real-Time Filtering**:
   - Live search matching student name, ID, or email address.
   - Dropdown filter by course of study.
   - Dropdown filter by enrollment status (Active, Probation, Inactive).

6. **Local Persistence**:
   - Synchronizes automatically with the browser's `localStorage`, preserving records across browser refreshes.

---

## 📚 Technical Rubric Alignment & Conceptual Explanations

### 1. JavaScript Data Types (10 Marks)
- **Strings**: Used for textual data such as `id` ("STU-001"), `name` ("Lerato Phakoe"), `email` ("lerato@limkokwing.ac.ls"), and `course`.
- **Numbers**: The student `age` is explicitly handled as a number (using `Number(formData.age)`) rather than a string.
- **Booleans**: Logical flags like `isValid` (form validation), `isEditMode`, and modal open/close states.
- **Arrays**: Used to hold the list of students (`students`) and available course offerings (`coursesList`).
- **Objects**: Each individual student record is structured as an object containing key-value pairs representing the student's attributes.

### 2. Variable Declarations: `const`, `let`, and `var` (8 Marks)
- **`const`**: Used by default for all references that must not be reassigned. In React, functional components, hooks (`useState`), imported modules, and arrow functions are declared with `const` to prevent accidental reassignment.
- **`let`**: Used when variables require reassignment or when collecting dynamic errors (e.g., `let errors = {}` inside `validateStudentForm`).
- **`var`**: Function-scoped and hoisted. Demonstrated with full explanatory notes inside `src/utils/typesAndVariablesDemo.js` to illustrate the difference between legacy function-scoping and modern block-scoping (`let` / `const`).

### 3. Functions & Application Logic (12 Marks)
- **User-Defined Functions**: Traditional functions (`function validateStudentForm(...)`, `function loadStudentsFromStorage()`) provide clear, reusable utilities with input parameters and return values.
- **Arrow Functions**: Concise arrow functions (`const handleSaveStudent = (...) => { ... }`) are used for React event handlers and inline callbacks.
- **Array Methods**:
  - `.map()`: Transforms data for rendering JSX table rows and dropdown options.
  - `.filter()`: Powers the multi-criteria search and filter dashboard, as well as student deletion.
  - `.some()`: Checks for duplicate student IDs.
  - `.find()`: Retrieves specific student objects for deletion previews.

### 4. React Components & Props (10 Marks)
The app is decomposed into reusable, focused functional components:
- `App.jsx`: Root container orchestrating state and CRUD operations.
- `Navbar.jsx`: Displays university brand and live student count badge.
- `StudentDashboard.jsx`: Search bar, filter dropdowns, and "Add Student" trigger.
- `StudentTable.jsx`: Table rendering with action buttons and empty-state messaging.
- `StudentModal.jsx`: Unified Add and Edit modal with input validation.
- `DeleteModal.jsx`: Confirmation dialog preventing accidental loss of data.

### 5. React State & Event Handling (12 Marks)
- Uses React's `useState` hook for dynamic UI state updates.
- Uses `useEffect` hook to persist updates to `localStorage`.
- Event handling via `onChange`, `onClick`, and `onSubmit` with `e.preventDefault()` to avoid page reloads.

### 6. Modal Dialogs & User Experience (15 Marks)
- Modals feature semi-transparent backdrop overlays with backdrop-click to dismiss.
- Clear Cancel buttons and prominent primary actions.
- Form controls display inline error feedback in red when validation fails.

---

## 🚀 How to Run the Project Locally

### Prerequisites
- [Node.js](https://nodejs.org/) (Version 16 or newer installed)

### Steps:
1. Open your terminal in this project directory:
   ```bash
   cd student-management-system
   ```
2. Install project dependencies:
   ```bash
   npm install
   ```
3. Start the local development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to the displayed local address (typically `http://localhost:3000` or `http://localhost:5173`).

---

## 🧪 Testing Checklist (Demonstration for Lecturer)

- [x] **Add Student**: Click "+ Add New Student", fill in fields, and click Save. Notice student appears at the top of the table.
- [x] **Validation**: Try submitting blank fields or age as "-5" or "200". Observe red error messages preventing submission.
- [x] **Duplicate ID Check**: Try adding a student with an ID that already exists. Observe duplicate ID error.
- [x] **Edit Student**: Click "Edit" on any row, modify their age or course, and click Update. The table reflects changes immediately.
- [x] **Delete Student**: Click "Delete" on any row. A confirmation modal appears. Confirming removes the student.
- [x] **Search & Filter**: Type a name into the search bar or select a course from the dropdown. Table filters dynamically.
- [x] **Persistence**: Refresh the browser page (`F5`). All additions, edits, and deletions remain saved in `localStorage`.

---

## 🌐 Deployment Instructions (Netlify / Vercel)

### Option A: Deploy to Netlify
1. Create a free account at [Netlify](https://www.netlify.com/).
2. Push your project to GitHub (see below).
3. In Netlify dashboard, click **Add new site** > **Import an existing project**.
4. Select your GitHub repository.
5. Set:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Click **Deploy**. Netlify provides a public `https://your-site.netlify.app` URL.

### Option B: Deploy to Vercel
1. Create a free account at [Vercel](https://vercel.com/).
2. Push your project to GitHub.
3. Click **Add New Project** and import your repository.
4. Vercel automatically detects Vite:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
5. Click **Deploy**. Vercel provides a public `https://your-site.vercel.app` URL.

---

## 📦 Pushing to GitHub
1. Initialize git in the project root:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Interactive Student Management System"
   ```
2. Create a new repository on GitHub (e.g. `student-management-system`).
3. Link and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/student-management-system.git
   git push -u origin main
   ```
