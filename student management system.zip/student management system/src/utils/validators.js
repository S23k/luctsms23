const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Form validation for Add and Edit student records
export function validateStudentForm(formData, existingStudents = [], isEditMode = false) {
  let errors = {};

  // 1. Student Number validation (e.g., 901030000 format)
  if (!formData.id || !formData.id.trim()) {
    errors.id = "Student number is required (e.g., 901030000)";
  } else {
    const trimmedId = formData.id.trim();
    if (!/^\d{8,10}$/.test(trimmedId)) {
      errors.id = "Student number must be numeric (e.g., 901030000)";
    } else if (!isEditMode) {
      // Check for duplicate ID using array method .some()
      const isDuplicate = existingStudents.some(
        (student) => student.id === trimmedId
      );
      if (isDuplicate) {
        errors.id = "A student with this number already exists";
      }
    }
  }

  // 2. Full Name validation
  if (!formData.name || !formData.name.trim()) {
    errors.name = "Full name is required";
  } else if (formData.name.trim().length < 2) {
    errors.name = "Full name must be at least 2 characters";
  }

  // 3. Age validation (must be positive number between 16 and 100)
  const numericAge = Number(formData.age);
  if (formData.age === "" || formData.age === null || formData.age === undefined) {
    errors.age = "Age is required";
  } else if (isNaN(numericAge) || !Number.isInteger(numericAge)) {
    errors.age = "Age must be a valid whole number";
  } else if (numericAge < 16 || numericAge > 100) {
    errors.age = "Age must be a realistic student age (between 16 and 100)";
  }

  // 4. Email validation
  if (!formData.email || !formData.email.trim()) {
    errors.email = "Email address is required";
  } else if (!EMAIL_REGEX.test(formData.email.trim())) {
    errors.email = "Please enter a valid email format (e.g. leratophakoe@gmail.com)";
  }

  // 5. Course selection validation
  if (!formData.course || !formData.course.trim()) {
    errors.course = "Please select a course of study";
  }

  // 6. Enrollment status validation
  if (!formData.status || !formData.status.trim()) {
    errors.status = "Please select an enrollment status";
  }

  // Calculate if form is valid using Object.keys()
  const isValid = Object.keys(errors).length === 0;

  return {
    isValid,
    errors
  };
}
