// JavaScript Data Types Demonstration
// Primitive types
export const sampleStudentName = "Ntseliseng Moloi"; // string
export const sampleCourse = "Diploma in Information Technology"; // string
export const sampleStudentAge = 21; // number
export const sampleIsEnrolled = true; // boolean

// Reference types
export const sampleStudentObject = {
  id: "901030001",
  name: "Ntseliseng Moloi",
  age: 21,
  email: "ntselisengmoloi@gmail.com",
  course: "Diploma in Information Technology",
  status: "Active"
};

export const sampleCoursesList = [
  "Diploma in Information Technology",
  "Diploma in Business Information Technology",
  "Diploma in Multimedia",
  "Diploma in Software Engineering"
];

// Scope demonstration: const vs let vs var
export function demonstrateVariableScopes() {
  const institute = "Limkokwing University"; // block-scoped, cannot reassign
  let activeStudentCount = 0; // block-scoped, reassignable
  activeStudentCount += 1;

  if (true) {
    var legacyVersion = "v1.0.0"; // function-scoped: accessible outside if-block
    let blockNote = "private"; // block-scoped: only inside if-block
  }

  return { institute, activeStudentCount, legacyVersion };
}

// User-defined function
export function formatStudentName(rawName) {
  if (!rawName || typeof rawName !== "string") return "";
  return rawName.trim();
}

// Arrow function
export const isSensibleStudentAge = (age) => {
  const numericAge = Number(age);
  return !isNaN(numericAge) && numericAge >= 16 && numericAge <= 100;
};
