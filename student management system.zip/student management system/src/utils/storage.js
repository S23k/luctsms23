// Default sample student records
export const INITIAL_STUDENTS = [
  {
    id: "901030001",
    name: "Lerato Phakoe",
    age: 20,
    email: "leratophakoe@gmail.com",
    course: "Diploma in Information Technology",
    status: "Active"
  },
  {
    id: "901030002",
    name: "Thabo Mofokeng",
    age: 22,
    email: "thabomofokeng@gmail.com",
    course: "Diploma in Business Information Technology",
    status: "Active"
  },
  {
    id: "901030003",
    name: "Kamohelo Radebe",
    age: 21,
    email: "kamoheloradebe@gmail.com",
    course: "Diploma in Information Technology",
    status: "Probation"
  },
  {
    id: "901030004",
    name: "Puleng Sekhonyana",
    age: 23,
    email: "pulengsekhonyana@gmail.com",
    course: "Diploma in Business Information Technology",
    status: "Inactive"
  }
];

const STORAGE_KEY = "diwa2110_student_records_v3";

// Load records from localStorage with fallback to default data
export function loadStudentsFromStorage() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (error) {
    console.error("Could not load from localStorage:", error);
  }
  return INITIAL_STUDENTS;
}

// Save records to localStorage
export function saveStudentsToStorage(studentsList) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(studentsList));
  } catch (error) {
    console.error("Could not save records to localStorage:", error);
  }
}
