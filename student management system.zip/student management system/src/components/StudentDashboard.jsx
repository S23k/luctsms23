import React from 'react';

// Controls for search, filters, and add modal
function StudentDashboard({
  searchQuery,
  onSearchChange,
  selectedCourse,
  onCourseChange,
  selectedStatus,
  onStatusChange,
  onOpenAddModal,
  totalFiltered,
  coursesList
}) {
  return (
    <section className="dashboard-controls-card">
      <div className="controls-row">
        {/* Search Input */}
        <div className="control-group search-group">
          <label htmlFor="search-input">Search Records</label>
          <div className="input-with-icon">
            <span className="search-icon">🔍</span>
            <input
              id="search-input"
              type="text"
              placeholder="Search by Student Number, Name, or Email..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="text-input"
            />
            {searchQuery && (
              <button
                type="button"
                className="clear-btn"
                onClick={() => onSearchChange("")}
                title="Clear search"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Filter by Course */}
        <div className="control-group">
          <label htmlFor="course-filter">Filter Course</label>
          <select
            id="course-filter"
            value={selectedCourse}
            onChange={(e) => onCourseChange(e.target.value)}
            className="select-input"
          >
            <option value="All">All Courses</option>
            {coursesList.map((course) => (
              <option key={course} value={course}>
                {course}
              </option>
            ))}
          </select>
        </div>

        {/* Filter by Status */}
        <div className="control-group">
          <label htmlFor="status-filter">Filter Status</label>
          <select
            id="status-filter"
            value={selectedStatus}
            onChange={(e) => onStatusChange(e.target.value)}
            className="select-input"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Probation">Probation</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        {/* Add Student Primary Action */}
        <div className="control-group action-group">
          <label className="desktop-only">&nbsp;</label>
          <button
            type="button"
            className="btn btn-primary"
            onClick={onOpenAddModal}
          >
            <span className="btn-icon">➕</span>
            Add New Student
          </button>
        </div>
      </div>

      <div className="results-summary">
        Showing <strong>{totalFiltered}</strong> matching {totalFiltered === 1 ? 'student' : 'students'}
      </div>
    </section>
  );
}

export default StudentDashboard;
