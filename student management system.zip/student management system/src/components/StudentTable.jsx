import React from 'react';

// Displays student records table with Edit and Delete actions
function StudentTable({ students, onEdit, onDelete }) {
  // Helper to assign color-coded CSS badge class based on status
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Active':
        return 'badge-active';
      case 'Probation':
        return 'badge-probation';
      case 'Inactive':
        return 'badge-inactive';
      default:
        return 'badge-default';
    }
  };

  // If no students match filters or list is empty
  if (students.length === 0) {
    return (
      <div className="empty-state-card">
        <div className="empty-icon">📂</div>
        <h3>No Student Records Found</h3>
        <p>No student matches your current filter or search criteria. Try resetting filters or add a new student.</p>
      </div>
    );
  }

  return (
    <div className="table-responsive-wrapper">
      <table className="student-table" aria-label="Student Directory">
        <thead>
          <tr>
            <th>Student Number</th>
            <th>Full Name</th>
            <th>Age</th>
            <th>Email Address</th>
            <th>Course of Study</th>
            <th>Enrollment Status</th>
            <th className="actions-header">Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              {/* Student Number */}
              <td className="id-cell">
                <span className="id-badge">{student.id}</span>
              </td>

              {/* Full Name */}
              <td className="name-cell">
                <strong>{student.name}</strong>
              </td>

              {/* Age */}
              <td>{student.age} yrs</td>

              {/* Email */}
              <td className="email-cell">
                <a href={`mailto:${student.email}`}>{student.email}</a>
              </td>

              {/* Course */}
              <td>{student.course}</td>

              {/* Status */}
              <td>
                <span className={`status-badge ${getStatusBadgeClass(student.status)}`}>
                  ● {student.status}
                </span>
              </td>

              {/* Action Buttons */}
              <td className="actions-cell">
                <div className="action-buttons-group">
                  <button
                    type="button"
                    className="btn btn-sm btn-edit"
                    onClick={() => onEdit(student)}
                    title="Edit student details"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-sm btn-delete"
                    onClick={() => onDelete(student)}
                    title="Delete student record"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentTable;
