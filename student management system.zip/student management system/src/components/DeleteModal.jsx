import React from 'react';

// Modal to confirm student record deletion
function DeleteModal({ isOpen, student, onClose, onConfirm }) {
  if (!isOpen || !student) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="modal-backdrop" onClick={handleBackdropClick} role="dialog" aria-modal="true">
      <div className="modal-card modal-delete">
        <div className="modal-header">
          <h2>⚠️ Confirm Deletion</h2>
          <button
            type="button"
            className="modal-close-btn"
            onClick={onClose}
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        <div className="modal-body">
          <p>Are you sure you want to delete this student record?</p>
          <div className="delete-target-preview">
            <div><strong>Student Number:</strong> {student.id}</div>
            <div><strong>Name:</strong> {student.name}</div>
            <div><strong>Course:</strong> {student.course}</div>
          </div>
          <p className="warning-note">This action cannot be undone.</p>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => onConfirm(student.id)}
          >
            Yes, Delete Student
          </button>
        </div>
      </div>
    </div>
  );
}

export default DeleteModal;
