import React from 'react';

// Navbar with student count badge
function Navbar({ totalStudents }) {
  return (
    <header className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <div className="brand-icon">🎓</div>
          <div className="brand-text">
            <h1>Student Management System</h1>
            <span className="subtitle">DIWA2110 • Limkokwing University</span>
          </div>
        </div>
        <div className="navbar-stats">
          <div className="stat-pill">
            <span className="stat-label">Total Records:</span>
            <span className="stat-value">{totalStudents}</span>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
