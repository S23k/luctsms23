import React, { useState, useEffect } from 'react';
import { validateStudentForm } from '../utils/validators';

// Modal for adding or editing a student record
function StudentModal({
  isOpen,
  mode,
  initialData,
  existingStudents,
  coursesList,
  onClose,
  onSave
}) {
  // Form input state object
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    age: '',
    email: '',
    course: coursesList[0] || '',
    status: 'Active'
  });

  // Inline validation error messages state object
  const [errors, setErrors] = useState({});

  // When modal opens or initialData changes, populate or reset fields
  useEffect(() => {
    if (isOpen) {
      if (mode === 'edit' && initialData) {
        setFormData({
          id: initialData.id,
          name: initialData.name,
          age: initialData.age.toString(),
          email: initialData.email,
          course: initialData.course,
          status: initialData.status
        });
      } else {
        // Reset to clean default values for "add" mode
        setFormData({
          id: '',
          name: '',
          age: '',
          email: '',
          course: coursesList[0] || '',
          status: 'Active'
        });
      }
      setErrors({});
    }
  }, [isOpen, mode, initialData, coursesList]);

  // If modal is not open, do not render into DOM
  if (!isOpen) return null;

  // Generic controlled input change handler
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));

    // Clear error for this field as the user begins typing
    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null
      }));
    }
  };

  // Form submission handler
  const handleSubmit = (e) => {
    e.preventDefault();

    const isEditMode = mode === 'edit';
    const validationResult = validateStudentForm(formData, existingStudents, isEditMode);

    if (!validationResult.isValid) {
      setErrors(validationResult.errors);
      return;
    }

    // Convert age to Number primitive type before passing back to parent
    const preparedStudent = {
      id: formData.id.trim(),
      name: formData.name.trim(),
      age: Number(formData.age),
      email: formData.email.trim().toLowerCase(),
      course: formData.course,
      status: formData.status
    };

    onSave(preparedStudent);
  };

  // Close when user clicks backdrop
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="modal-backdrop" onClick={handleBackdropClick} role="dialog" aria-modal="true">
      <div className="modal-card">
        {/* Modal Header */}
        <div className="modal-header">
          <h2>{mode === 'edit' ? '✏️ Edit Student Record' : '➕ Add New Student'}</h2>
          <button
            type="button"
            className="modal-close-btn"
            onClick={onClose}
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} noValidate>
          <div className="modal-body">
            {/* Student Number */}
            <div className="form-group">
              <label htmlFor="student-id">
                Student Number <span className="required">*</span>
              </label>
              <input
                id="student-id"
                name="id"
                type="text"
                inputMode="numeric"
                placeholder="e.g. 901030000"
                value={formData.id}
                onChange={handleInputChange}
                disabled={mode === 'edit'} // ID cannot be edited once created
                className={errors.id ? 'input-error' : ''}
              />
              {errors.id && <span className="error-message">{errors.id}</span>}
              {mode === 'edit' && (
                <small className="help-text">Student Number cannot be modified.</small>
              )}
            </div>

            {/* Full Name */}
            <div className="form-group">
              <label htmlFor="student-name">
                Full Name <span className="required">*</span>
              </label>
              <input
                id="student-name"
                name="name"
                type="text"
                placeholder="e.g. Thabo Mofokeng"
                value={formData.name}
                onChange={handleInputChange}
                className={errors.name ? 'input-error' : ''}
              />
              {errors.name && <span className="error-message">{errors.name}</span>}
            </div>

            {/* Age & Email in 2 columns */}
            <div className="form-row-2">
              <div className="form-group">
                <label htmlFor="student-age">
                  Age <span className="required">*</span>
                </label>
                <input
                  id="student-age"
                  name="age"
                  type="number"
                  min="16"
                  max="100"
                  placeholder="e.g. 21"
                  value={formData.age}
                  onChange={handleInputChange}
                  className={errors.age ? 'input-error' : ''}
                />
                {errors.age && <span className="error-message">{errors.age}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="student-email">
                  Email Address <span className="required">*</span>
                </label>
                <input
                  id="student-email"
                  name="email"
                  type="email"
                  placeholder="leratophakoe@gmail.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={errors.email ? 'input-error' : ''}
                />
                {errors.email && <span className="error-message">{errors.email}</span>}
              </div>
            </div>

            {/* Course of Study */}
            <div className="form-group">
              <label htmlFor="student-course">
                Course of Study <span className="required">*</span>
              </label>
              <select
                id="student-course"
                name="course"
                value={formData.course}
                onChange={handleInputChange}
                className={errors.course ? 'input-error' : ''}
              >
                {coursesList.map((course) => (
                  <option key={course} value={course}>
                    {course}
                  </option>
                ))}
              </select>
              {errors.course && <span className="error-message">{errors.course}</span>}
            </div>

            {/* Enrollment Status */}
            <div className="form-group">
              <label htmlFor="student-status">
                Enrollment Status <span className="required">*</span>
              </label>
              <select
                id="student-status"
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                className={errors.status ? 'input-error' : ''}
              >
                <option value="Active">Active</option>
                <option value="Probation">Probation</option>
                <option value="Inactive">Inactive</option>
              </select>
              {errors.status && <span className="error-message">{errors.status}</span>}
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onClose}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              {mode === 'edit' ? 'Update Student' : 'Save Student'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default StudentModal;
