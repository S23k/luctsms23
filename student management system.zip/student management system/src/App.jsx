import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import StudentDashboard from './components/StudentDashboard';
import StudentTable from './components/StudentTable';
import StudentModal from './components/StudentModal';
import DeleteModal from './components/DeleteModal';
import { loadStudentsFromStorage, saveStudentsToStorage } from './utils/storage';
import { sampleCoursesList } from './utils/typesAndVariablesDemo';

// Main application component
function App() {
  const [students, setStudents] = useState(() => loadStudentsFromStorage());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('add');
  const [selectedStudent, setSelectedStudent] = useState(null);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState(null);
  const [feedback, setFeedback] = useState(null);

  // Sync state changes with localStorage
  useEffect(() => {
    saveStudentsToStorage(students);
  }, [students]);

  const showFeedback = (message, type = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleOpenAdd = () => {
    setModalMode('add');
    setSelectedStudent(null);
    setStudentModalOpen(true);
  };

  const handleOpenEdit = (student) => {
    setModalMode('edit');
    setSelectedStudent(student);
    setStudentModalOpen(true);
  };

  const handleOpenDelete = (student) => {
    setStudentToDelete(student);
    setDeleteModalOpen(true);
  };

  // Add or update student
  const handleSaveStudent = (studentData) => {
    if (modalMode === 'add') {
      setStudents((prev) => [studentData, ...prev]);
      showFeedback(`Student "${studentData.name}" added successfully!`, 'success');
    } else {
      setStudents((prev) =>
        prev.map((item) => (item.id === studentData.id ? studentData : item))
      );
      showFeedback(`Student "${studentData.name}" updated successfully!`, 'success');
    }
    setStudentModalOpen(false);
  };

  // Delete student
  const handleConfirmDelete = (studentId) => {
    const student = students.find((s) => s.id === studentId);
    const name = student ? student.name : studentId;
    setStudents((prev) => prev.filter((item) => item.id !== studentId));
    setDeleteModalOpen(false);
    setStudentToDelete(null);
    showFeedback(`Student "${name}" was deleted.`, 'info');
  };

  // Filter students based on search query, course, and status
  const filteredStudents = students.filter((student) => {
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      query === '' ||
      student.name.toLowerCase().includes(query) ||
      student.id.toLowerCase().includes(query) ||
      student.email.toLowerCase().includes(query);

    const matchesCourse =
      selectedCourse === 'All' || student.course === selectedCourse;

    const matchesStatus =
      selectedStatus === 'All' || student.status === selectedStatus;

    return matchesSearch && matchesCourse && matchesStatus;
  });

  return (
    <div className="app-layout">
      <Navbar totalStudents={students.length} />

      <main className="main-content">
        {/* Floating feedback notification banner */}
        {feedback && (
          <div className={`feedback-banner feedback-${feedback.type}`}>
            <span>{feedback.message}</span>
            <button
              type="button"
              className="feedback-close"
              onClick={() => setFeedback(null)}
            >
              ✕
            </button>
          </div>
        )}

        {/* Dashboard Filters & Add Button */}
        <StudentDashboard
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCourse={selectedCourse}
          onCourseChange={setSelectedCourse}
          selectedStatus={selectedStatus}
          onStatusChange={setSelectedStatus}
          onOpenAddModal={handleOpenAdd}
          totalFiltered={filteredStudents.length}
          coursesList={sampleCoursesList}
        />

        {/* Student Records Table */}
        <section className="student-list-container">
          <StudentTable
            students={filteredStudents}
            onEdit={handleOpenEdit}
            onDelete={handleOpenDelete}
          />
        </section>
      </main>

      {/* Add / Edit Student Modal */}
      <StudentModal
        isOpen={studentModalOpen}
        mode={modalMode}
        initialData={selectedStudent}
        existingStudents={students}
        coursesList={sampleCoursesList}
        onClose={() => setStudentModalOpen(false)}
        onSave={handleSaveStudent}
      />

      {/* Delete Confirmation Modal */}
      <DeleteModal
        isOpen={deleteModalOpen}
        student={studentToDelete}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

export default App;
